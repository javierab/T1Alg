#define TRUE 1
#define FALSE 0
#define new(X) (X *)malloc(sizeof(X))
